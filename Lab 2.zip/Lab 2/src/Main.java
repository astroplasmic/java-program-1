/*

   Name: Alexander Young

   Email: alexyoungodin@gmail.com

   References:

   Collaborated with:

*/

    import java.util.Scanner;
    public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Player player = new Player();

        boolean running = true;

        while (running) {

            System.out.println("THE SIMPLE MATH GAME");
            System.out.println("1. Start The Game");
            System.out.println("2. View The Player Info");
            System.out.println("3. Exit The Game");
            System.out.print("Choose an option: ");

            int choice = input.nextInt();
            System.out.println();

            switch (choice) {

                case 1:
                    player.setScore(0);

                    System.out.println("Level 1:");
                    System.out.print("What is 5 + 3? ");
                    int answer1 = input.nextInt();
                    if (answer1 == 8) {
                        System.out.println("Correct!");
                        player.setScore(player.getScore() + 1);
                    } else {
                        System.out.println("Wrong!");
                    }

                    System.out.println("\nLevel 2:");
                    System.out.print("What is 6 * 2? ");
                    int answer2 = input.nextInt();
                    if (answer2 == 12) {
                        System.out.println("That is Correct");
                        player.setScore(player.getScore() + 1);
                    } else {
                        System.out.println("That is Wrong");
                    }

                    System.out.println("\nLevel 3:");
                    System.out.print("What is 15 - 4? ");
                    int answer3 = input.nextInt();
                    if (answer3 == 11) {
                        System.out.println("That is Correct");
                        player.setScore(player.getScore() + 1);
                    } else {
                        System.out.println("That is Wrong");
                    }

                    System.out.println("\nGame Over");
                    System.out.println("Your Score: " + player.getScore());

                    if (player.getScore() > player.getHighScore()) {
                        player.setHighScore(player.getScore());
                        System.out.println("New High Score");
                    }

                    System.out.println();
                    break;

                case 2:
                    player.printPlayerInfo();
                    System.out.println();
                    break;

                case 3:
                    running = false;
                    System.out.println("Thank you for playing The Game");
                    break;

                default:
                    System.out.println("Invalid choice. Please Try again.\n");
            }
        }

        input.close();
    }
}
