public class Player {

    private String name;
    private int score;
    private int highScore;

    public Player() {
        name = "player 1";
        score = 0;
        highScore = 0;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    public int getHighScore() {
        return highScore;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setHighScore(int highScore) {
        this.highScore = highScore;
    }

    public void printPlayerInfo() {
        System.out.println("Player Name: " + name);
        System.out.println("High Score: " + highScore);
    }
}
